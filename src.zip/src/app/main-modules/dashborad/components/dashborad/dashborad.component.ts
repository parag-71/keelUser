import { Component } from '@angular/core';
import {  CdkDragDrop, CdkDragStart, transferArrayItem } from '@angular/cdk/drag-drop';
import { DashboradService } from '../../dashborad-service/dashborad.service';
import * as Global from '../../../../../environments/environment'
import { MatDialog } from '@angular/material/dialog';
import { PreviewDashboardUserComponent } from '../preview-dashboard-user/preview-dashboard-user.component';
import { PreviewDashboardPlantComponent } from '../preview-dashboard-plant/preview-dashboard-plant.component';
import Swal from 'sweetalert2';
import { CommonService } from 'src/app/core/services/common.service';
import { Router } from '@angular/router';
import { Util } from 'src/app/core/resource/utils';
import { EndUserService } from 'src/app/core/services/end-user.service';
import { forkJoin, of } from 'rxjs';
@Component({
  selector: 'app-dashborad',
  templateUrl: './dashborad.component.html',
  styleUrls: ['./dashborad.component.scss']
})
export class DashboradComponent {
  baseUrl = Global.environment.BASE_URL
  utiObj = new Util();
  pagination:any = {
    siteIds:[]
  }
  pendingChanges: any[] = [];
  plantPendingChanges: any[] = [];
  resourceView: 'people' | 'plant' | 'both' = 'people';
  constructor(
    public dashboradService:DashboradService,
    public dialog: MatDialog,
    public commonService:CommonService,
    public router: Router,
    public endUserService: EndUserService

  ) {
    this.dashboradService.allSiteData = []
    this.dashboradService.displaySiteData = []
  }
  ngOnInit() {
    this.dashboradService.siteNameList()
    const localSiteList:any = JSON.parse(localStorage.getItem('slectSite') || '[]')
    localSiteList.forEach((item: any) => {
      if (item.siteId) {
        this.pagination.siteIds.push(item.siteId);
      }
    });
    // getAllSitesUserList() alone populates both People and Plant boards
    // (allSitesUserList already returns userData[] + plantData[] per site).
    this.dashboradService.getAllSitesUserList(this.pagination)
  }

  // Unified People/Plant/Both: every card is normalized to { type: 'person' | 'plant' }.
  // combinedSiteData holds all items per site; visibleSiteData filters by the active tab.
  // One drop-list/drop-handler/drag-handler serves all three tabs.

  private _combinedCache: { peopleRef: any[] | null; plantRef: any[] | null; data: any[]; ids: string[] } = {
    peopleRef: null,
    plantRef: null,
    data: [],
    ids: []
  };

  private rebuildCombinedCache(): void {
    const peopleSites = this.dashboradService.displaySiteData || [];
    const plantSites = this.dashboradService.displayPlantSiteData || [];
    const siteMap = new Map<any, any>();

    peopleSites.forEach((site: any) => {
      siteMap.set(site.siteId, {
        siteId: site.siteId,
        siteName: site.siteName,
        usrId: site.usrId,
        userData: site.userData || [],
        plantData: [],
        combinedData: (site.userData || []).map((item: any) => ({ ...item, type: 'person' }))
      });
    });

    plantSites.forEach((site: any) => {
      const existing = siteMap.get(site.siteId);
      const plantItems = (site.plantData || []).map((item: any) => ({ ...item, type: 'plant' }));
      if (existing) {
        existing.plantData = site.plantData || [];
        existing.combinedData.push(...plantItems);
      } else {
        siteMap.set(site.siteId, {
          siteId: site.siteId,
          siteName: site.siteName,
          usrId: site.usrId,
          userData: [],
          plantData: site.plantData || [],
          combinedData: plantItems
        });
      }
    });

    const data = Array.from(siteMap.values());
    this._combinedCache = {
      peopleRef: peopleSites,
      plantRef: plantSites,
      data,
      ids: data.map((site: any) => `${site.siteId}_${site.usrId}_${site.siteName}`)
    };
  }

  // Call whenever the REAL source arrays are mutated in-place (splice/push),
  // since that alone won't change the top-level array reference the cache keys off.
  private invalidateCombinedCache(): void {
    this._combinedCache.peopleRef = null;
    this._combinedCache.plantRef = null;
  }

  get combinedSiteData(): any[] {
    const peopleSites = this.dashboradService.displaySiteData || [];
    const plantSites = this.dashboradService.displayPlantSiteData || [];
    if (this._combinedCache.peopleRef !== peopleSites || this._combinedCache.plantRef !== plantSites) {
      this.rebuildCombinedCache();
    }
    return this._combinedCache.data;
  }

  // Single drop-list id list, used for cdkDropListConnectedTo in ALL three tabs.
  get dropListIds(): string[] {
    this.combinedSiteData; // ensures cache is fresh
    return this._combinedCache.ids;
  }

  // True when a header search or any advanced popup filter is active.
  private get isDashboardFilterActive(): boolean {
    return !!this.commonService.search
      || this.dashboradService.filterItem.some((f: any) => Object.values(f).some((v: any) => Array.isArray(v) && v.length > 0));
  }

  get visibleSiteData(): any[] {
    return this.combinedSiteData
      .map((site: any) => ({
        ...site,
        visibleData: this.resourceView === 'both'
          ? site.combinedData
          : site.combinedData.filter((item: any) => item.type === (this.resourceView === 'people' ? 'person' : 'plant'))
      }))
      // combinedSiteData is a UNION of people- and plant-matched sites, so
      // while a filter is active, drop sites with nothing to show on this
      // tab (e.g. matched only via a plant tag while on the People tab).
      // With no filter active, keep every site as a drag-drop target.
      .filter((site: any) => !this.isDashboardFilterActive || site.visibleData.length > 0);
  }

  // ---- Single drop handler for People / Plant / Both ----
  handleDrop(event: CdkDragDrop<any[]> | any) {
    const dropped: any = event.previousContainer.data[event.previousIndex];
    if (!dropped || !dropped.type) return;
    const isPerson = dropped.type === 'person';

    // Always use assignId/senderId off the item - do not substitute usrId for people.
    var assignId = dropped.assignId;
    var senderId = dropped.senderId;
    var assignName = isPerson ? dropped.usrFirstname : dropped.pltTitle;
    var preSiteId = event.previousContainer.id.split('_', 3)[0]
    var siteId = event.container.id.split('_', 1)[0]
    var receiverId = event.container.id.split('_', 2)[1]
    var siteName = event.container.id.split('_', 3)[2]

    if (this.commonService?.usrpermission.usrType == 2 || this.commonService?.usrpermission.usrType == 1) {
      if (preSiteId !== siteId) {
        // Mutate the real source arrays (not the transient visibleData) and
        // invalidate the cache - that alone is enough to re-render correctly.
        const realSites = isPerson ? this.dashboradService.displaySiteData : this.dashboradService.displayPlantSiteData;
        const destSite = (realSites || []).find((s: any) => String(s.siteId) === String(siteId));
        const srcSite = (realSites || []).find((s: any) => String(s.siteId) === String(preSiteId));
        if (destSite && srcSite) {
          const srcArray = isPerson ? (srcSite.userData = srcSite.userData || []) : (srcSite.plantData = srcSite.plantData || []);
          const destArray = isPerson ? (destSite.userData = destSite.userData || []) : (destSite.plantData = destSite.plantData || []);
          const srcIndex = srcArray.findIndex((item: any) => item.assignId === assignId);
          if (srcIndex > -1) {
            const [movedItem] = srcArray.splice(srcIndex, 1);
            const { type, ...cleanItem } = movedItem;
            destArray.push(cleanItem);
          }
        }

        const changes = isPerson ? this.pendingChanges : this.plantPendingChanges;
        const existingIndex = changes.findIndex((c) => c.assignId === assignId);
        if (existingIndex > -1) {
          changes[existingIndex] = { siteId, receiverId, assignId, preSiteId, senderId };
        } else {
          changes.push({ siteId, receiverId, assignId, preSiteId, senderId });
        }
        this.invalidateCombinedCache();
      }
    } else if (event.previousContainer.id.split('_', 3)[1] == this.commonService?.usrpermission.usrId) {
      if (event.previousContainer != event.container) {
        Swal.fire({
          icon: 'warning',
          text: `Do you want to move ${assignName} to ${siteName} site`,
          width: '27rem',
          confirmButtonText: 'Yes',
          confirmButtonColor: 'rgb(223,129,62)',
          cancelButtonText: 'No',
          showCancelButton: true,
        }).then((result) => {
          if (result.isConfirmed && event.previousContainer != event.container) {
            if (isPerson) {
              this.dashboradService.assignUserInSite(siteId, receiverId, assignId, preSiteId);
            } else {
              this.dashboradService.assignPlantInSite(siteId, receiverId, assignId, preSiteId);
            }
            this.invalidateCombinedCache();
          }
        });
      }
    }
  }

  // ---- Single drag-start handler for People / Plant / Both ----
  onItemDragStarted(event: CdkDragStart): void {
    const data = event.source.data;
    const isPerson = data.type === 'person';
    if (data.suStatus == 1 || data.spStatus == 1) {
      this.commonService.Alert(
        isPerson ? 'This user is pending for approval' : 'This plant is pending for approval',
        'error'
      );
    }
    if (data.suStatus == 3 || data.spStatus == 3) {
      this.commonService.Alert(
        isPerson
          ? 'The user is already assigned to a site and pending for approval.'
          : 'The plant is already assigned to a site and pending for approval.',
        'error'
      );
    }
  }

  trackByCombinedId(index: number, item: any) {
    return (item.type === 'person' ? item.usrId : item.assignId) + '_' + item.type;
  }
  trackBySiteId(index: number, site: any){
    return site.siteId
  }

  saveChanges() {
    if (!this.pendingChanges.length && !this.plantPendingChanges.length) {
      this.commonService.Alert('No changes to save.', 'info');
      return;
    }

    Swal.fire({
      icon: 'warning',
      text: 'Do you want to save all changes?',
      width: '27rem',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      showCancelButton: true,
      confirmButtonColor: 'rgb(223,129,62)',
    }).then((result) => {
      if (!result.isConfirmed) return;

      const userCall$ = this.pendingChanges.length
        ? this.endUserService.assignUsersInSitesByAdmin({ userSiteData: this.pendingChanges })
        : of(null);
      const plantCall$ = this.plantPendingChanges.length
        ? this.endUserService.assignPlantsInSitesByAdmin({ plantSiteData: this.plantPendingChanges })
        : of(null);

      forkJoin([userCall$, plantCall$]).subscribe(([userResult, plantResult]: any) => {
        const userOk = !userResult || userResult.status == '200';
        const plantOk = !plantResult || plantResult.status == '200';

        if (userResult) {
          userOk
            ? (this.dashboradService.originalSiteData = JSON.parse(JSON.stringify(this.dashboradService.displaySiteData)), this.pendingChanges = [])
            : this.commonService.ApiErrAlert(userResult);
        }
        if (plantResult) {
          plantOk
            ? (this.dashboradService.originalPlantSiteData = JSON.parse(JSON.stringify(this.dashboradService.displayPlantSiteData)), this.plantPendingChanges = [])
            : this.commonService.ApiErrAlert(plantResult);
        }
        if (userOk && plantOk) {
          this.commonService.successAlert('Changes saved successfully.');
        }
        this.invalidateCombinedCache();
      });
    });
  }

  // assignUsersInSitesByAdmin() {
  //   const paramData = {
  //     userSiteData: this.pendingChanges
  //   };
  //   this.endUserService.assignUsersInSitesByAdmin(paramData).subscribe((result: any) => {
  //     if (result.status == '200') {
  //       this.commonService.successAlert(result.message);
  //       this.dashboradService.originalSiteData = JSON.parse(JSON.stringify(this.dashboradService.displaySiteData));
  //       this.pendingChanges = [];
  //     } else {
  //       this.commonService.ApiErrAlert(result)
  //     }
  //   })
  // }

  // assignPlantsInSitesByAdmin() {
  //   const paramData = {
  //     plantSiteData: this.plantPendingChanges
  //   };
  //   this.endUserService.assignPlantsInSitesByAdmin(paramData).subscribe((result: any) => {
  //     if (result.status == '200') {
  //       this.commonService.successAlert(result.message);
  //       this.dashboradService.originalPlantSiteData = JSON.parse(JSON.stringify(this.dashboradService.displayPlantSiteData));
  //       this.plantPendingChanges = [];
  //     } else {
  //       this.commonService.ApiErrAlert(result)
  //     }
  //   })
  // }

  cancelChanges() {
    Swal.fire({
      icon: 'warning',
      text: 'All unsaved changes will be reverted.',
      width: '27rem',
      confirmButtonText:'Yes',
      cancelButtonText:'No',
      showCancelButton:true,
      confirmButtonColor: 'rgb(223,129,62)',
    }).then((result) => {
      if (result.isConfirmed) {
        // revert to original snapshot
        this.dashboradService.displaySiteData = JSON.parse(
          JSON.stringify(this.dashboradService.originalSiteData)
        );
        this.dashboradService.displayPlantSiteData = JSON.parse(
          JSON.stringify(this.dashboradService.originalPlantSiteData)
        );
        this.pendingChanges = [];
        this.plantPendingChanges = [];
        this.invalidateCombinedCache();
      }
    });
  }

  getChipKey(index: number): string {
    const keys = ['siteName', 'roleName', 'licName', 'trName', 'comptName'];
    return keys[index];
  }
  setResourceView(view: 'people' | 'plant' | 'both') {
    this.resourceView = view;
  }
  previewUser(user: any, site: any) {
    const dialogRef = this.dialog.open(PreviewDashboardUserComponent, {
      data: { user: user, site: site }, width: '43rem', autoFocus: false, disableClose: true,
    })
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.dashboradService.getAllSitesUserList(this.pagination);
        this.invalidateCombinedCache();
      }
      this.dashboradService.userDetails = ''
    })
  }
  previewPlant(plant: any, site: any) {
    const dialogRef = this.dialog.open(PreviewDashboardPlantComponent, {
      data: { plant: plant, site: site }, width: '43rem', autoFocus: false, disableClose: true,
    })
    dialogRef.afterClosed().subscribe(result => {
      if (result == 'success') {
        this.dashboradService.getAllSitesPlantList(this.pagination);
        this.invalidateCombinedCache();
      }
      this.dashboradService.plantDetails = ''
    })
  }
  redirectToSite(site:any, type:string = 'people'){
    this.router.navigate(['sites/preview-site-user', site.siteId], { queryParams: { type } });
  }
  selectSite(site:any){
    var localSiteList:any = JSON.parse(localStorage.getItem('slectSite') || '[]')
    var check = localSiteList.some((list:any)=>list.siteId == site.siteId)
    var siteIds:any = []
    if(site.siteName == 'All'){
      if(check){
      this.pagination.siteIds = []
      this.dashboradService.selectedSite = []
      localStorage.setItem('slectSite',JSON.stringify(this.dashboradService.selectedSite))
      }else{
        this.dashboradService.selectedSite = this.dashboradService.siteList
        this.dashboradService.selectedSite.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
        this.pagination.siteIds = siteIds
        localStorage.setItem('slectSite',JSON.stringify(this.dashboradService.selectedSite))
      }
    }else if(check){
      let updatedSite = localSiteList.filter((val:any)=>val.siteId != site.siteId)
      let siteIndex = this.utiObj.getIndexOfArrayData(updatedSite, "siteName", "All")
      siteIndex != -1 ? updatedSite.splice(siteIndex, 1) : ''
      updatedSite.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
      this.pagination.siteIds = siteIds
      this.dashboradService.selectedSite.length != this.dashboradService.siteList.length ? this.dashboradService.selectedSite = this.dashboradService.selectedSite.filter((site:any)=>site.siteId != '') : ''
      localStorage.setItem('slectSite',JSON.stringify(updatedSite))
    }else{
      localSiteList.push(site)
      localSiteList.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
      this.pagination.siteIds = siteIds
      this.dashboradService.selectedSite.length+1 != this.dashboradService.siteList.length ? this.dashboradService.selectedSite = this.dashboradService.selectedSite.filter((site:any)=>site.siteId != '') : this.dashboradService.selectedSite =localSiteList
      localStorage.setItem('slectSite',JSON.stringify(localSiteList))
    }
    // Single call - populates both People and Plant boards.
    this.dashboradService.getAllSitesUserList(this.pagination)
  }
  compareFn(site1: any, site2: any): boolean {
    return site1 && site2 ? site1.siteId === site2.siteId  : site1 === site2;
  }
  removeFilter(item:any,index:any){
    this.dashboradService.removeFilterLabel.next({item,index})
  }
  getSelectedLabel(){
    if(this.dashboradService.selectedSite.some((element:any)=>element.siteName == 'All')){
      return "All"
    }else{
      return this.dashboradService.selectedSite.map((option:any) => option.siteName).join(', ');
    }
  }
  ngOnDestroy() {
    this.dashboradService.allSiteData =[]
	  this.dashboradService.displaySiteData = []
    this.dashboradService.allPlantSiteData = []
    this.dashboradService.displayPlantSiteData = []
    this.commonService.userCount = ''
    this.commonService.plantCount = ''
    this.dashboradService.setinitialData()
  }
}
