import { Component, ElementRef, Inject } from '@angular/core';
import { ComponentType } from '@angular/cdk/portal';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import { finalize } from 'rxjs';
import Swal from 'sweetalert2';
import { CommonService } from 'src/app/core/services/common.service';
import { EndUserService } from 'src/app/core/services/end-user.service';
import { LoaderService } from 'src/app/core/services/loader.service';
import { AddVacancyRoleComponent } from '../add-vacancy-role/add-vacancy-role.component';
import { AddVacancyPlantComponent } from '../add-vacancy-plant/add-vacancy-plant.component';

/**
 * "Manage Roles" / "Manage Plants" dialog, opened from the gear icon in the
 * planner's resource-column header.
 *
 * Lists both types in separate sections:
 *   - type 2 (added from the planner)  -> editable and deletable here
 *   - type 1 (Settings / Plant Resources master records) -> read-only, shown
 *     only so the person can see what already exists
 *
 * data: { vacancyType: 'people' | 'plant', entityLabel: string }
 * Closes with 'changed' if anything was added, edited or deleted, so the
 * planner knows to refresh its dropdown and grid.
 */
@Component({
  selector: 'app-manage-planner-entities',
  templateUrl: './manage-planner-entities.component.html',
  styleUrls: ['./manage-planner-entities.component.scss']
})
export class ManagePlannerEntitiesComponent {
  /** Split by type so the list can show them as two separate sections. */
  masterEntities: any[] = [];
  plannerEntities: any[] = [];
  /** Row to mark as selected — set after picking an existing record in Add. */
  highlightedEntityId: any = null;
  /** Shown in a banner so the match is obvious even before scrolling to it. */
  highlightedEntityName: string = '';
  private changed = false;

  constructor(
    public dialogRef: MatDialogRef<ManagePlannerEntitiesComponent>,
    private host: ElementRef,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog,
    public commonService: CommonService,
    public endUserService: EndUserService,
    public loaderService: LoaderService
  ) { }

  ngOnInit(): void {
    this.loadEntities();
  }

  private get isPlant(): boolean {
    return this.data.vacancyType == 'plant';
  }

  loadEntities() {
    // companyRoleList / plantList are used rather than the planner's own list
    // endpoints because sending no roleType / pltType returns BOTH types in a
    // single call, which is exactly what this screen shows.
    const entityApi = this.isPlant
      ? this.endUserService.plantList({ index: '0', limit: '100' })
      : this.endUserService.companyRoleList({ search: '' });
    this.loaderService.show();
    entityApi.pipe(finalize(() => this.loaderService.hide())).subscribe((result: any) => {
      if (result.status == '200' || result.status == 200) {
        const all = (result.data || []).map((entity: any) => ({
          entityId: this.isPlant ? entity.pltId : entity.roleId,
          entityName: this.isPlant ? entity.pltTitle : entity.roleName,
          entityType: this.isPlant ? entity.pltType : entity.roleType
        }));
        // Anything not explicitly type 2 is treated as a master record, so an
        // API that omits the type field can't accidentally expose delete on one.
        this.plannerEntities = all.filter((entity: any) => entity.entityType == 2);
        this.masterEntities = all.filter((entity: any) => entity.entityType != 2);
        this.scrollToSelected();
      } else {
        this.commonService.ApiErrAlert(result);
      }
    });
  }

  /**
   * Brings the selected row into view. The list can be long enough to scroll,
   * so a row highlighted after picking an existing record in the Add dialog
   * would otherwise sit off-screen and the person wouldn't see it at all.
   *
   * The timeout lets Angular render the rows first — the element doesn't exist
   * yet at the moment the data is assigned.
   */
  private scrollToSelected() {
    if (!this.highlightedEntityId) {
      return;
    }
    setTimeout(() => {
      const row = this.host.nativeElement.querySelector('.selected_row');
      row?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  openAddEdit(entity?: any) {
    const dialogType: ComponentType<any> = this.isPlant ? AddVacancyPlantComponent : AddVacancyRoleComponent;
    const dialogRef = this.dialog.open(dialogType, {
      data: entity
        ? { from: 'edit', entityId: entity.entityId, entityName: entity.entityName }
        : { from: 'add' },
      width: '27rem',
      autoFocus: false,
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result?.status != 'success') {
        return;
      }
      if (result.entity) {
        // An existing record was picked from the Add dialog's suggestions —
        // nothing was created, so just mark it as selected in the list.
        this.highlightedEntityId = result.entity.entityId;
        this.highlightedEntityName = result.entity.entityName;
      } else {
        this.changed = true;
        this.highlightedEntityId = null;
        this.highlightedEntityName = '';
      }
      this.loadEntities();
    });
  }

  deleteEntity(entity: any) {
    const label = this.data.entityLabel.toLowerCase();
    Swal.fire({
      icon: 'warning',
      text: `Deleting this ${label} will also delete all the entries related to it in the planner`,
      width: '27rem',
      confirmButtonText: 'Yes',
      confirmButtonColor: 'rgb(223,129,62)',
      cancelButtonText: 'No',
      showCancelButton: true,
    }).then((confirm) => {
      if (!confirm.isConfirmed) {
        return;
      }
      const deleteApi = this.isPlant
        ? this.endUserService.deletePlant({ pltId: entity.entityId })
        : this.endUserService.deleteCompanyRole({ roleId: entity.entityId });
      this.loaderService.show();
      deleteApi.pipe(finalize(() => this.loaderService.hide())).subscribe((res: any) => {
        if (res.status == 200 || res.status == '200') {
          this.commonService.successAlert(res.message);
          this.changed = true;
          this.loadEntities();
        } else {
          this.commonService.ApiErrAlert(res);
        }
      });
    });
  }

  closeDialog() {
    this.dialogRef.close(this.changed ? 'changed' : '');
  }
}
