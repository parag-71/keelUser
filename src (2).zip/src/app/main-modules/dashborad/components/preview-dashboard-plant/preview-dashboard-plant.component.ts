import { Component, Inject } from '@angular/core';
import { DashboradService } from '../../dashborad-service/dashborad.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import * as Global from '../../../../../environments/environment'
import Swal from 'sweetalert2';
import { CommonService } from 'src/app/core/services/common.service';
import { Util } from 'src/app/core/resource/utils';
@Component({
  selector: 'app-preview-dashboard-plant',
  templateUrl: './preview-dashboard-plant.component.html',
  styleUrls: ['./preview-dashboard-plant.component.scss']
})
export class PreviewDashboardPlantComponent {
  baseUrl = Global.environment.BASE_URL
  utilObj = new Util();
  constructor(
    public dashboradService:DashboradService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<PreviewDashboardPlantComponent>,
    public commonService:CommonService
  ) { }
  ngOnInit() {
    this.dashboradService.getPlantDetails(this.data.plant.assignId ? this.data.plant.assignId : this.data.plant.pltId ? this.data.plant.pltId : '')
    this.dashboradService.siteNameList()
  }
  // Mirrors PreviewDashboardUserComponent.assginUser() exactly, just targeting the plant assignment API.
  assginPlant(siteData:any){
      if((this.data.site.usrId == this.commonService.loginUserDetail.usrId || this.data.plant.assignId == this.data.site.usrId) && this.commonService.loginUserDetail.usrType == 2 && this.data.plant.spStatus != 3){
        Swal.fire({
          icon: 'warning',
          text: `Do you want to move ${this.data.plant.pltTitle} to ${siteData.siteName} site`,
          width: '27rem',
          confirmButtonText: 'Yes',
          confirmButtonColor: 'rgb(223,129,62)',
          cancelButtonText: 'No',
          showCancelButton: true,
        }).then((result) => {
          if (result.isConfirmed) {
              this.dashboradService.assignPlantInSite(siteData.siteId,siteData.usrId,this.data.plant.assignId,this.data.site.siteId)
              this.dialogRef.close('success')
          }
        });
      }else{
        this.commonService.Alert('Sorry, only site leaders are authorized to assign plants from one site to another.','error')
      }
  }
  closeDialog(){
    this.dialogRef.close()
  }
}