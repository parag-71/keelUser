import { Component } from '@angular/core';
import {  CdkDragDrop, CdkDragStart, transferArrayItem } from '@angular/cdk/drag-drop';
import { DashboradService } from '../../dashborad-service/dashborad.service';
import * as Global from '../../../../../environments/environment'
import { MatDialog } from '@angular/material/dialog';
import { PreviewDashboardUserComponent } from '../preview-dashboard-user/preview-dashboard-user.component';
import { PreviewDashboardPlantComponent } from '../preview-dashboard-plant/preview-dashboard-plant.component';
import Swal from 'sweetalert2';
import { CommonService } from 'src/app/core/services/common.service';
import { Router } from '@angular/router';
import { Util } from 'src/app/core/resource/utils';
import { EndUserService } from 'src/app/core/services/end-user.service';
@Component({
  selector: 'app-dashborad',
  templateUrl: './dashborad.component.html',
  styleUrls: ['./dashborad.component.scss']
})
export class DashboradComponent {
  baseUrl = Global.environment.BASE_URL
  utiObj = new Util();
  pagination:any = {
    siteIds:[]
  }
  pendingChanges: any[] = [];
  plantPendingChanges: any[] = [];
  resourceView: 'people' | 'plant' | 'both' = 'people';
  constructor(
    public dashboradService:DashboradService,
    public dialog: MatDialog,
    public commonService:CommonService,
    public router: Router,
    public endUserService: EndUserService

  ) {
    this.dashboradService.allSiteData = []
    this.dashboradService.displaySiteData = []
  }
  ngOnInit() {
    this.dashboradService.siteNameList()
    const localSiteList:any = JSON.parse(localStorage.getItem('slectSite') || '[]')
    localSiteList.forEach((item: any) => {
      if (item.siteId) {
        this.pagination.siteIds.push(item.siteId);
      }
    });
    this.dashboradService.getAllSitesUserList(this.pagination)
    this.dashboradService.getAllSitesPlantList(this.pagination)
  }
  drop(event: CdkDragDrop<string[]> | any) {
    var assignId = event.previousContainer.data[event.previousIndex].assignId
    var senderId = event.previousContainer.data[event.previousIndex].senderId
    var assignName = event.previousContainer.data[event.previousIndex].usrFirstname
    var preSiteId = event.previousContainer.id.split('_', 3)[0]
    var siteId = event.container.id.split('_', 1)[0]
    var receiverId = event.container.id.split('_', 2)[1]
    var siteName = event.container.id.split('_', 3)[2]

    if (this.commonService?.usrpermission.usrType == 2 || this.commonService?.usrpermission.usrType == 1) {
      // ✅ Check if dropped into another site (not the same one)
      if (preSiteId !== siteId) {
        if (event.previousContainer !== event.container) {
          transferArrayItem(
            event.previousContainer.data,
            event.container.data,
            event.previousIndex,
            event.currentIndex
          );
        }
        const existingIndex = this.pendingChanges.findIndex(
          (c) => c.assignId === assignId
        );

        if (existingIndex > -1) {
          this.pendingChanges[existingIndex] = { siteId, receiverId, assignId, preSiteId, senderId };
        } else {
          this.pendingChanges.push({ siteId, receiverId, assignId, preSiteId, senderId });
        }
      }
    } else if (event.previousContainer.id.split('_', 3)[1] == this.commonService?.usrpermission.usrId) {
      if (event.previousContainer != event.container) {
        Swal.fire({
          icon: 'warning',
          text: `Do you want to move ${assignName} to ${siteName} site`,
          width: '27rem',
          confirmButtonText: 'Yes',
          confirmButtonColor: 'rgb(223,129,62)',
          cancelButtonText: 'No',
          showCancelButton: true,
        }).then((result) => {
          if (result.isConfirmed && event.previousContainer != event.container) {
            this.dashboradService.assignUserInSite(siteId, receiverId, assignId, preSiteId);
          }
        });
      }
    }
  }

  plantDrop(event: CdkDragDrop<string[]> | any) {
    var assignId = event.previousContainer.data[event.previousIndex].assignId
    var senderId = event.previousContainer.data[event.previousIndex].senderId
    var assignName = event.previousContainer.data[event.previousIndex].pltTitle
    var preSiteId = event.previousContainer.id.split('_', 3)[0]
    var siteId = event.container.id.split('_', 1)[0]
    var receiverId = event.container.id.split('_', 2)[1]
    var siteName = event.container.id.split('_', 3)[2]

    if (this.commonService?.usrpermission.usrType == 2 || this.commonService?.usrpermission.usrType == 1) {
      if (preSiteId !== siteId) {
        if (event.previousContainer !== event.container) {
          transferArrayItem(
            event.previousContainer.data,
            event.container.data,
            event.previousIndex,
            event.currentIndex
          );
        }
        const existingIndex = this.plantPendingChanges.findIndex(
          (c) => c.assignId === assignId
        );
        if (existingIndex > -1) {
          this.plantPendingChanges[existingIndex] = { siteId, receiverId, assignId, preSiteId, senderId };
        } else {
          this.plantPendingChanges.push({ siteId, receiverId, assignId, preSiteId, senderId });
        }
      }
    } else if (event.previousContainer.id.split('_', 3)[1] == this.commonService?.usrpermission.usrId) {
      if (event.previousContainer != event.container) {
        Swal.fire({
          icon: 'warning',
          text: `Do you want to move ${assignName} to ${siteName} site`,
          width: '27rem',
          confirmButtonText: 'Yes',
          confirmButtonColor: 'rgb(223,129,62)',
          cancelButtonText: 'No',
          showCancelButton: true,
        }).then((result) => {
          if (result.isConfirmed && event.previousContainer != event.container) {
            this.dashboradService.assignPlantInSite(siteId, receiverId, assignId, preSiteId);
          }
        });
      }
    }
  }

  saveChanges() {
    if (!this.pendingChanges.length && !this.plantPendingChanges.length) {
      this.commonService.Alert('No changes to save.', 'info');
      return;
    }

    Swal.fire({
      icon: 'warning',
      text: 'Do you want to save all changes?',
      width: '27rem',
      confirmButtonText:'Yes',
      cancelButtonText:'No',
      showCancelButton:true,
      confirmButtonColor: 'rgb(223,129,62)',
    }).then((result) => {
      if (result.isConfirmed) {
        if (this.pendingChanges.length) this.assignUsersInSitesByAdmin()
        if (this.plantPendingChanges.length) this.assignPlantsInSitesByAdmin()
      }
    });
  }

  assignUsersInSitesByAdmin() {
    const paramData = {
      userSiteData: this.pendingChanges
    };
    this.endUserService.assignUsersInSitesByAdmin(paramData).subscribe((result: any) => {
      if (result.status == '200') {
        this.commonService.successAlert(result.message);
        this.dashboradService.originalSiteData = JSON.parse(JSON.stringify(this.dashboradService.displaySiteData));
        this.pendingChanges = [];
      } else {
        this.commonService.ApiErrAlert(result)
      }
    })
  }

  assignPlantsInSitesByAdmin() {
    const paramData = {
      plantSiteData: this.plantPendingChanges
    };
    this.endUserService.assignPlantsInSitesByAdmin(paramData).subscribe((result: any) => {
      if (result.status == '200') {
        this.commonService.successAlert(result.message);
        this.dashboradService.originalPlantSiteData = JSON.parse(JSON.stringify(this.dashboradService.displayPlantSiteData));
        this.plantPendingChanges = [];
      } else {
        this.commonService.ApiErrAlert(result)
      }
    })
  }

  cancelChanges() {
    Swal.fire({
      icon: 'warning',
      text: 'All unsaved changes will be reverted.',
      width: '27rem',
      confirmButtonText:'Yes',
      cancelButtonText:'No',
      showCancelButton:true,
      confirmButtonColor: 'rgb(223,129,62)',
    }).then((result) => {
      if (result.isConfirmed) {
        // revert to original snapshot
        this.dashboradService.displaySiteData = JSON.parse(
          JSON.stringify(this.dashboradService.originalSiteData)
        );
        this.dashboradService.displayPlantSiteData = JSON.parse(
          JSON.stringify(this.dashboradService.originalPlantSiteData)
        );
        this.pendingChanges = [];
        this.plantPendingChanges = [];
      }
    });
  }

  onDragStarted(event: CdkDragStart): void {
    if(event.source.data.suStatus == 1){
      this.commonService.Alert('This user is pending for approval','error')
    }
    if(event.source.data.suStatus == 3){
      this.commonService.Alert('The user is already assigned to a site and pending for approval.','error')
    }
  }
  
  trackByUserId(index: number, user: any) {
    return user.usrId;
  }
  trackByPlantId(index: number, plant: any) {
    return plant.assignId;
  }
  onPlantDragStarted(event: CdkDragStart): void {
    if(event.source.data.spStatus == 1){
      this.commonService.Alert('This plant is pending for approval','error')
    }
    if(event.source.data.spStatus == 3){
      this.commonService.Alert('The plant is already assigned to a site and pending for approval.','error')
    }
  }
  trackBySiteId(index: number, site: any){
    return site.siteId
  }
  // ---- "Both" view: union of people-sites and plant-sites by siteId ----
  // Note: userData/plantData below are the SAME array references held on
  // dashboradService.displaySiteData / displayPlantSiteData, so drag & drop,
  // pendingChanges tracking, save/cancel all keep working exactly as before.
  get combinedSiteData(): any[] {
    const peopleSites = this.dashboradService.displaySiteData || [];
    const plantSites = this.dashboradService.displayPlantSiteData || [];
    const siteMap = new Map<any, any>();

    peopleSites.forEach((site: any) => {
      siteMap.set(site.siteId, {
        siteId: site.siteId,
        siteName: site.siteName,
        usrId: site.usrId,
        userData: site.userData || [],
        plantData: []
      });
    });

    plantSites.forEach((site: any) => {
      const existing = siteMap.get(site.siteId);
      if (existing) {
        existing.plantData = site.plantData || [];
      } else {
        siteMap.set(site.siteId, {
          siteId: site.siteId,
          siteName: site.siteName,
          usrId: site.usrId,
          userData: [],
          plantData: site.plantData || []
        });
      }
    });

    return Array.from(siteMap.values());
  }
  // explicit connect-lists so people & plant drop-lists never cross-connect
  // even though they're visually merged into the same site column
  get peopleDropListIds(): string[] {
    return this.combinedSiteData.map((site: any) => `${site.siteId}_${site.usrId}_${site.siteName}`);
  }
  get plantDropListIds(): string[] {
    return this.combinedSiteData.map((site: any) => `${site.siteId}_${site.usrId}_${site.siteName}_plant`);
  }
  getChipKey(index: number): string {
    const keys = ['siteName', 'roleName', 'licName', 'trName', 'comptName'];
    return keys[index];
  }
  setResourceView(view: 'people' | 'plant' | 'both') {
    this.resourceView = view;
  }
  previewUser(user:any,site:any){
    const dialogRef = this.dialog.open(PreviewDashboardUserComponent, {
      data:{user: user, site : site},
      width: '43rem',
      autoFocus: false,
      disableClose: true,
    })
    dialogRef.afterClosed().subscribe(result => {
      result == 'success' ? this.dashboradService.getAllSitesUserList(this.pagination) : ''
      this.dashboradService.userDetails = ''
    })
  }
  // Mirrors previewUser() exactly, just opening the Plant popup with plant data.
  previewPlant(plant:any,site:any){
    const dialogRef = this.dialog.open(PreviewDashboardPlantComponent, {
      data:{plant: plant, site : site},
      width: '43rem',
      autoFocus: false,
      disableClose: true,
    })
    dialogRef.afterClosed().subscribe(result => {
      result == 'success' ? this.dashboradService.getAllSitesPlantList(this.pagination) : ''
      this.dashboradService.plantDetails = ''
    })
  }
  redirectToSite(site:any, type:string = 'people'){
    this.router.navigate(['sites/preview-site-user', site.siteId], { queryParams: { type } });
  }
  selectSite(site:any){
    var localSiteList:any = JSON.parse(localStorage.getItem('slectSite') || '[]')
    var check = localSiteList.some((list:any)=>list.siteId == site.siteId)
    var siteIds:any = []
    if(site.siteName == 'All'){
      if(check){
      this.pagination.siteIds = []
      this.dashboradService.selectedSite = []
      localStorage.setItem('slectSite',JSON.stringify(this.dashboradService.selectedSite))
      }else{
        this.dashboradService.selectedSite = this.dashboradService.siteList
        this.dashboradService.selectedSite.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
        this.pagination.siteIds = siteIds
        localStorage.setItem('slectSite',JSON.stringify(this.dashboradService.selectedSite))
      }
    }else if(check){
      let updatedSite = localSiteList.filter((val:any)=>val.siteId != site.siteId)
      let siteIndex = this.utiObj.getIndexOfArrayData(updatedSite, "siteName", "All")
      siteIndex != -1 ? updatedSite.splice(siteIndex, 1) : ''
      updatedSite.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
      this.pagination.siteIds = siteIds
      this.dashboradService.selectedSite.length != this.dashboradService.siteList.length ? this.dashboradService.selectedSite = this.dashboradService.selectedSite.filter((site:any)=>site.siteId != '') : ''
      localStorage.setItem('slectSite',JSON.stringify(updatedSite))
    }else{
      localSiteList.push(site)
      localSiteList.map((id:any)=>id.siteId ? siteIds.push(id.siteId) : '')
      this.pagination.siteIds = siteIds
      this.dashboradService.selectedSite.length+1 != this.dashboradService.siteList.length ? this.dashboradService.selectedSite = this.dashboradService.selectedSite.filter((site:any)=>site.siteId != '') : this.dashboradService.selectedSite =localSiteList
      localStorage.setItem('slectSite',JSON.stringify(localSiteList))
    }
    this.dashboradService.getAllSitesUserList(this.pagination)
    this.dashboradService.getAllSitesPlantList(this.pagination)
  }
  compareFn(site1: any, site2: any): boolean {
    return site1 && site2 ? site1.siteId === site2.siteId  : site1 === site2;
  }
  removeFilter(item:any,index:any){
    this.dashboradService.removeFilterLabel.next({item,index})
  }
  getSelectedLabel(){
    if(this.dashboradService.selectedSite.some((element:any)=>element.siteName == 'All')){
      return "All"
    }else{
      return this.dashboradService.selectedSite.map((option:any) => option.siteName).join(', ');
    }
  }
  ngOnDestroy() {
    this.dashboradService.allSiteData =[]
	  this.dashboradService.displaySiteData = []
    this.dashboradService.allPlantSiteData = []
    this.dashboradService.displayPlantSiteData = []
    this.commonService.userCount = ''
    this.commonService.plantCount = ''
    this.dashboradService.setinitialData()
  }
}