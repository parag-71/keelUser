import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import * as Global from './../resource/global';

@Injectable({
  providedIn: 'root'
})
export class EndUserService {

  constructor(public http: HttpService) { }

  login(paramData:any):any{
    return this.http.post(
			Global.login,
			paramData
		);
  }

  logout(paramData:any):any{
    return this.http.post(
			Global.logout,
			paramData
		);
  }

  changeUserPassword(paramData:any):any{
    return this.http.post(
			Global.changeUserPassword,
			paramData
		);
  }

  getUserAccess(paramData:any):any{
    return this.http.post(
			Global.getUserAccess,
			paramData,
      'backgroundApi'
		);
  }

  //Site API Fn
  addOrUpdateSite(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateSite,
			paramData
		);
  }

  siteList(paramData:any):any{
    return this.http.post(
			Global.siteList,
			paramData
		);
  }

  deleteSite(paramData:any):any{
    return this.http.post(
			Global.deleteSite,
			paramData
		);
  }

  //Resource API Fn
  addOrUpdateUser(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateUser,
			paramData
		);
  }
  userList(paramData:any):any{
    return this.http.post(
			Global.userList,
			paramData
		);
  }
  changeUserStatus(paramData:any):any{
    return this.http.post(
			Global.changeUserStatus,
			paramData
		);
  }
  deleteUser(paramData:any):any{
    return this.http.post(
			Global.deleteUser,
			paramData
		);
  }
  userNameList(paramData:any):any{
    return this.http.post(
			Global.userNameList,
			paramData
		);
  }

  updateUserTrainingRecord(paramData:any):any{
    return this.http.post(
			Global.updateUserTrainingRecord,
			paramData
		);
  }

  userTrainingRecordList(paramData:any):any{
    return this.http.post(
			Global.userTrainingRecordList,
			paramData
		);
  }

  updateUserLicences(paramData:any):any{
    return this.http.post(
			Global.updateUserLicences,
			paramData
		);
  }
  userLicencesList(paramData:any):any{
    return this.http.post(
			Global.userLicencesList,
			paramData
		);
  }

  updateUserCompetencies(paramData:any):any{
    return this.http.post(
			Global.updateUserCompetencies,
			paramData
		);
  }

  userCompetenciesList(paramData:any):any{
    return this.http.post(
			Global.userCompetenciesList,
			paramData
		);
  }

  userDetails(paramData:any):any{
    return this.http.post(
			Global.userDetails,
			paramData
		);
  }


  //Plant Resource API Fn
  addPlant(paramData:any):any{
    return this.http.post(
			Global.addPlant,
			paramData
		);
  }
  plantList(paramData:any):any{
    return this.http.post(
			Global.plantList,
			paramData
		);
  }
  plantDetails(paramData:any):any{
    return this.http.post(
			Global.plantDetails,
			paramData
		);
  }
  updatePlant(paramData:any):any{
    return this.http.post(
			Global.updatePlant,
			paramData
		);
  }
  plantNameList(paramData:any):any{
    return this.http.post(
			Global.plantNameList,
			paramData
		);
  }
  deletePlant(paramData:any):any{
    return this.http.post(
			Global.deletePlant,
			paramData
		);
  }
  updatePlantResourceLicences(paramData:any):any{
    return this.http.post(
			Global.updatePlantResourceLicences,
			paramData
		);
  }
  plantResourceLicencesList(paramData:any):any{
    return this.http.post(
			Global.plantResourceLicencesList,
			paramData
		);
  }

  // Role API
  roleList(paramData:any):any{
    return this.http.post(
			Global.roleList,
			paramData
		);
  }

  // training Record
  trainingRecordList(paramData:any):any{
    return this.http.post(
			Global.trainingRecordList,
			paramData
		);
  }

  // licences Record
  licencesList(paramData:any):any{
    return this.http.post(
			Global.licencesList,
			paramData
		);
  }

  // competencies API
  competenciesList(paramData:any):any{
    return this.http.post(
			Global.competenciesList,
			paramData
		);
  }

  //dashboard API
  allSitesUserList(paramData:any):any{
    return this.http.post(
			Global.allSitesUserList,
			paramData
		);
  }

  assignUserInSite(paramData:any):any{
    return this.http.post(
			Global.assignUserInSite,
			paramData
		);
  }

  siteNameList(paramData:any):any{
    return this.http.post(
			Global.siteNameList,
			paramData
		);
  }

  assignUsersInSitesByAdmin(paramData:any):any{
    return this.http.post(
			Global.assignUsersInSitesByAdmin,
			paramData
		);
  }

  allSitesPlantList(paramData:any):any{
    return this.http.post(
			Global.allSitesPlantList,
			paramData
		);
  }

  assignPlantInSite(paramData:any):any{
    return this.http.post(
			Global.assignPlantInSite,
			paramData
		);
  }

  assignPlantsInSitesByAdmin(paramData:any):any{
    return this.http.post(
			Global.assignPlantsInSitesByAdmin,
			paramData
		);
  }

  //Request
  acceptSiteUser(paramData:any):any{
    return this.http.post(
			Global.acceptSiteUser,
			paramData
		);
  }

  siteUserRequestList(paramData:any):any{
    return this.http.post(
			Global.siteUserRequestList,
			paramData
		);
  }

  cancelSiteUserRequest(paramData:any):any{
    return this.http.post(
			Global.cancelSiteUserRequest,
			paramData
		);
  }
  sitePlantRequestList(paramData: any): any {
    return this.http.post(
      Global.sitePlantRequestList,
      paramData
    );
  }
  acceptSitePlant(paramData: any): any {
    return this.http.post(
      Global.acceptSitePlant,
      paramData
    );
  }
  cancelSitePlantRequest(paramData: any): any {
    return this.http.post(
      Global.cancelSitePlantRequest, 
      paramData);
  }
  sentRequestSiteNameList(paramData:any):any{
    return this.http.post(
			Global.sentRequestSiteNameList,
			paramData
		);
  }

  //forgot password
  forgotPassword(paramData:any):any{
    return this.http.post(
			Global.forgotPassword,
			paramData
		);
  }

  resetPassword(paramData:any):any{
    return this.http.post(
			Global.resetPassword,
			paramData
		);
  }


  // request demo 
  requestDemo(paramData:any):any{
    return this.http.post(
			Global.requestDemo,
			paramData
		);
  }

  //Resource Planner
  resourceList(paramData:any):any{
    return this.http.post(
			Global.resourceList,
			paramData
		);
  }
  addOrUpdateResourcePlanner(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateResourcePlanner,
			paramData
		);
  }
  resourcePlannerList(paramData:any):any{
    return this.http.post(
			Global.resourcePlannerList,
			paramData
		);
  }
  deleteResourcePlan(paramData:any):any{
    return this.http.post(
			Global.deleteResourcePlan,
			paramData
		);
  }
 
  //Resource (People) Vacancy Planner
  addOrUpdateResourceVacantPlanner(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateResourceVacantPlanner,
			paramData
		);
  }
  resourceRoleList(paramData:any):any{
    return this.http.post(
			Global.resourceRoleList,
			paramData
		);
  }
  resourceVacantPlannerList(paramData:any):any{
    return this.http.post(
			Global.resourceVacantPlannerList,
			paramData
		);
  }
  deleteResourceVacantPlan(paramData:any):any{
    return this.http.post(
			Global.deleteResourceVacantPlan,
			paramData
		);
  }

  //Plant Vacancy Planner
  addOrUpdatePlantVacantPlanner(paramData:any):any{
    return this.http.post(
			Global.addOrUpdatePlantVacantPlanner,
			paramData
		);
  }
  plantListForVacantPlanner(paramData:any):any{
    return this.http.post(
			Global.plantListForVacantPlanner,
			paramData
		);
  }
  plantVacantPlannerList(paramData:any):any{
    return this.http.post(
			Global.plantVacantPlannerList,
			paramData
		);
  }
  deletePlantVacantPlan(paramData:any):any{
    return this.http.post(
			Global.deletePlantVacantPlan,
			paramData
		);
  }
  addOrUpdatePlannerPlant(paramData:any):any{
    return this.http.post(
			Global.addOrUpdatePlannerPlant,
			paramData
		);
  }

  //add Dummy Resource
  addOrUpdateDummyUser(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateDummyUser,
			paramData
		);
  }
  DummyUserList(paramData:any):any{
    return this.http.post(
			Global.DummyUserList,
			paramData
		);
  }
  deleteDummyUser(paramData:any):any{
    return this.http.post(
			Global.deleteDummyUser,
			paramData
		);
  }

  //Company setting
  addOrUpdateCompanyRole(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateCompanyRole,
			paramData
		);
  }
  companyRoleList(paramData:any):any{
    return this.http.post(
			Global.companyRoleList,
			paramData
		);
  }
  deleteCompanyRole(paramData:any):any{
    return this.http.post(
			Global.deleteCompanyRole,
			paramData
		);
  }

  addOrUpdateCompanyTrainingRecord(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateCompanyTrainingRecord,
			paramData
		);
  }
  companyTrainingRecordList(paramData:any):any{
    return this.http.post(
			Global.companyTrainingRecordList,
			paramData
		);
  }
  deleteCompanyTrainingRecord(paramData:any):any{
    return this.http.post(
			Global.deleteCompanyTrainingRecord,
			paramData
		);
  }

  addOrUpdateCompanyLicences(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateCompanyLicences,
			paramData
		);
  }
  companyLicencesList(paramData:any):any{
    return this.http.post(
			Global.companyLicencesList,
			paramData
		);
  }
  deleteCompanyLicences(paramData:any):any{
    return this.http.post(
			Global.deleteCompanyLicences,
			paramData
		);
  }

  addOrUpdateCompanyCompetencies(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateCompanyCompetencies,
			paramData
		);
  }
  companyCompetenciesList(paramData:any):any{
    return this.http.post(
			Global.companyCompetenciesList,
			paramData
		);
  }
  deleteCompanyCompetencies(paramData:any):any{
    return this.http.post(
			Global.deleteCompanyCompetencies,
			paramData
		);
  }

  addOrUpdateCompanyPlantLicences(paramData:any):any{
    return this.http.post(
			Global.addOrUpdateCompanyPlantLicences,
			paramData
		);
  }
  companyPlantLicencesList(paramData:any):any{
    return this.http.post(
			Global.companyPlantLicencesList,
			paramData
		);
  }
  deleteCompanyPlantLicences(paramData:any):any{
    return this.http.post(
			Global.deleteCompanyPlantLicences,
			paramData
		);
  }

  companyTagList(paramData: any): any {
    return this.http.post(Global.companyTagList, paramData);
  }
  addOrUpdateCompanyTag(paramData: any): any {
    return this.http.post(Global.addOrUpdateCompanyTag, paramData);
  }

}